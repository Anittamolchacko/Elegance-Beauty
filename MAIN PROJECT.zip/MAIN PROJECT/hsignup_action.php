<?php
include 'dbconnect.php';
//setcookie("name","");
			$name=$_POST['name'];
			$address=$_POST['address'];
			$place=$_POST['place'];
			$district=$_POST['district'];
			$email=$_POST['email'];
			$pwd=$_POST['password1'];
			$phone=$_POST['phone'];
			//$photo=$_POST['photo'];
/////////////////
$target_dir = "photo/";
$target_file = $target_dir ."elegance". basename($_FILES["fileToUpload"]["name"]);
echo $target_file;
/////////////////////			

$sql="select * from login where username='$email'";
$result=mysqli_query($con,$sql);
$rowcount=mysqli_num_rows($result);
if($rowcount==0)
{
//
				$a="insert into login(`username`,`pass`,`type`,`status`) values ('$email','$pwd',1,0)";

							if(mysqli_query($con,$a))
							  {
								  $q3=mysqli_query($con, "select login_id from login where username='$email'");
								  $q7=mysqli_fetch_array($q3,MYSQLI_ASSOC);
								  $lid=$q7['login_id'];
								  
			////////
		
$filename = $_FILES["fileToUpload"]["name"];
//echo $filename;
$file_basename = substr($filename, 0, strripos($filename, '.')); // get file extention
	$file_ext = substr($filename, strripos($filename, '.')); // get file name

$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size
if ($_FILES["fileToUpload"]["size"] > 900000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
        
        
     
        
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
			///////
 $q4="insert into homemakers_reg(`name`,`address`,`place`,`district_id`,`email`,`phone`,`photo`,`login_id`,`status1`) values('$name','$address','$place','$district','$email','$phone','$target_file','$lid',0)";
$q5=mysqli_query($con,$q4);
					
if($q5)
{
	header("location:../MAIN PROJECT/login.php?error=Successfully registered");
}
else
{
	header("location:../MAIN PROJECT/login.php?error=error");
}
}
						
}
else
{
	header("location:../MAIN PROJECT/login.php?error=User Already Exist");
											
}		
			
?>	