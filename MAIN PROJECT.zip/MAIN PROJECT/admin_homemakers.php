 <?php
session_start();
$login=$_SESSION['login'];
$type=$_SESSION['type'];
//$usr_name=$_SESSION['usr_name'];
if($login)
{
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>FancyShop - Ecommerce Bootstrap Template</title>
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,500,600,700,800" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Handlee" rel="stylesheet">	
	<link rel="stylesheet" href="css/animate.css" />
	<link rel="stylesheet" href="css/owl.theme.default.min.css" />
	<link rel="stylesheet" href="css/owl.carousel.min.css" />
	<link rel="stylesheet" href="css/meanmenu.min.css" />
	<link rel="stylesheet" href="css/venobox.css" />
	<link rel="stylesheet" href="css/font-awesome.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />	
	<link rel="stylesheet" href="style.css" />
	<link rel="stylesheet" href="css/responsive.css" />	
</head>
	<body>
	
		<!--  Preloader  -->
		
		<div class="preloader">
			<div class="status-mes">
				<div class="bigSqr">
					<div class="square first"></div>
					<div class="square second"></div>
					<div class="square third"></div>
					<div class="square fourth"></div>
				</div>
				<div class="text_loading text-center">loading</div>
			</div>
		</div>
		
	<?php include("a_menu.php"); 
	include("dbconnect.php");?>	
		
		
		
		
		
		
		
		
		
		<!-- Login Page -->
		<div class="login_page_area">
			<div class="container">
				<div class="row">
					
					</div>
					
						<div class="create_account_area">
							<h2 class="caa_heading">Homemakers</h2>
							<?php
//$se=" select * from `login`,`homemakers_reg` WHERE login.status=0 && login.login_id=homemakers_reg.login_id";
$se=" select * from `login`,`homemakers_reg` WHERE login.login_id=homemakers_reg.login_id";

//$se=" select * from `login`,`homemakers_reg` WHERE homemakers_reg.status=0 && login.login_id=homemakers_reg.login_id";
 $re=mysqli_query($con,$se);
 $no=1;
?>
					<table border="1" style="width: 100%;">
						<tr style="height: 40px">
						   
							<th style=" padding-left: 20px;">Sl No</th>
							<th style=" padding-left: 20px;">Name</th>
							<th style=" padding-left: 20px;">Photo</th>
							<th style=" padding-left: 20px;">Address</th>
							<th style=" padding-left: 20px;">Place</th>
							<th style=" padding-left: 20px;">email</th>
							<th style=" padding-left: 20px;">phone</th>
							<th  style=" padding-left: 20px;">Remark</th>
							
							
						</tr>
						<?php
					
							while($row=mysqli_fetch_array($re))
  
 {
					?>
    <tr>
	<td style="font-size: 15px;"> 
   <?php 
        echo $no;
    ?>
<td style="font-size: 15px;"> <a href="admin_homemaker_details.php" >
   <?php 
        echo $row['name'];
    ?>
  </a></td>
  <td align=center style="font-size: 15px;"> <a href="admin_homemaker_details.php" >
   <?php 
        $p=$row['photo'];
		$p="../$p";
        echo "<img src=$p width=70 height=80" ;
    ?>
	</td>
  <td style="font-size: 15px;"> 
   <?php 
        echo $row['address'];
    ?>
  </td>
<td style="font-size: 15px;">

<?php
echo $row['place'];
?>
</td>
<td style="font-size: 15px;">
<?php
echo $row['email'];
?>
</td>
<td style="font-size:15px;">

<?php
echo $row['phone'];
$app=$row['status'];
echo "<td width=70 align=center>";
if ($app=="0" || $app=="2")
{

if ($app=="0")
{
?>

  <form action="approve.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['login_id']; ?>"/>
    <input type="submit" value="Pending">
  </form>
  <?php 
}
else{
	?>
  <form action="approve.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['login_id']; ?>"/>
    <input type="submit" value="Approve">
  </form>

  <?php
}  
}
else 
{ ?><font color="green"><b> Approved<?php }?>
<?php
$rej=$row['status'];
if ($rej=="1")
{
?>

  <form action="reject.php" method="POST">
    <input type="hidden" name="id" value="<?php echo $row['login_id']; ?>"/>
    <input type="submit" value="Block">
	<?php 
}
else 
{ ?> <font color="red"><b> Blocked<?php }?>
  </form>  
  </td>
</tr>
<?php
$no++;
}
?>
</table>
							
						</div>
					
				</div>
			</div>
		</div>		
		<br><br><br><br><br><br>
		<!--  FOOTER START  -->
		<footer class="footer_area">
			<div class="container">
				<div class="row">				
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Site Developed by Anittamol Chacko ,anittamolchacko@mca.ajce.in &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; MCA@AJCE
					
				</div>
			</div>
	
		
			

		<script src="js/vendor/jquery-1.12.4.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.meanmenu.min.js"></script>
		<script src="js/jquery.mixitup.js"></script>
		<script src="js/jquery.counterup.min.js"></script>
		<script src="js/waypoints.min.js"></script>
		<script src="js/wow.min.js"></script>
		<script src="js/venobox.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/simplePlayer.js"></script>
		<script src="js/main.js"></script>
	</body>
</html>

<?php
}
else
	header("location:../login.php");
?>