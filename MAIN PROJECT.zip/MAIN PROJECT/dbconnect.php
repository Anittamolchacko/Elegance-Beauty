<?php
	$con=mysqli_connect('localhost','root','','elegancebeauty')
	or die('Error connecting to MYSQL server.');
//echo "ok";
?>