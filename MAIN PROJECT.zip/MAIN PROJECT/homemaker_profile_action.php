<?php
session_start();

include "dbconnect.php";
$hname=$_POST['hname'];
$haddress=$_POST['haddress'];
$hplace=$_POST['hplace'];
$hdistrict=$_POST['hdistrict'];
$hphone=$_POST['hphone'];
$login_id=$_SESSION['login_id'];
echo $hdistrict;
$sqll=mysqli_query($con," update homemakers_reg  set name='$hname',address='$haddress',place='$hplace',district_id='$hdistrict',phone='$hphone' where login_id='$login_id'");
header("location:homemaker_profile.php?error=Profile changed Sucessfuly!...");
?>