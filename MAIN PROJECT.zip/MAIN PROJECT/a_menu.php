
<!--  Start Header  -->
		 <!--  HEADER START  -->
			
			<div class="header_btm_area">
				<div class="container">
					<div class="row">		
						<div class="col-xs-12 col-sm-12 col-md-3"> 
						
							<a class="logo" href="index.php"><table border=0 width=120%><tr><td><img src="img/logo/logo.png"><td align=right></table> 
						</div><!--  End Col -->
						
						<div class="col-xs-12 col-sm-12 col-md-9 text-right">
							<div class="menu_wrap">
								<div class="main-menu">
									<nav>
										<ul>
											  <li><a href="admin_home.php">home</a></li>
												<li><a href="admin_homemakers.php">homemaker</a>
												<!-- Sub Menu -->
																					
											
											<li><a>Category <i class="fa fa-angle-down"></i></a>
												<!-- Sub Menu -->
												<ul class="sub-menu">
													<li><a href="product.php">Add product</a></li>
													
												</ul>
											</li>
											
											<li><a>View<i class="fa fa-angle-down"></i></a>
												<!-- Sub Menu -->
												<ul class="sub-menu">
													<li><a href="feedback.php">Feedback</a></li>
													<li><a href="rate.php">Rate</a></li>
													
												</ul>
											</li>
							
											</li>
											
											<li><a>Notification<i class="fa fa-angle-down"></i></a>
												<!-- Sub Menu -->
												<ul class="sub-menu">
													<li><a href="feedback.php">customer</a></li>
													<li><a href="rate.php">homemaker</a></li>
													<li><a href="message.php">message</a></li>
												</ul>
											</li>
							
											</li>
											<li><a href="homemaker.php">Account</a></li>
											
											<li><a href="logout.php">logout</a></li>
											
										</ul>
										
									</nav>
									
									
								</div> <!--  End Main Menu -->					

                                   
													
													
													<!-- Cart Button -->
													
												</div>											
											</div>			
												
												
																								
											</div><br>

	<?php  echo "<font size=4 color=green>Welcome :  Admin";?>

								
						</div><!--  End Col -->										
					</div>
				</div>
			</div>
		</header>
		<!--  End Header  -->