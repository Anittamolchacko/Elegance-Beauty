<?php
include "dbconnect.php";

$b=$_POST['id'];
//$sql=mysqli_query($con,"update homemakers_reg set status='0' where login_id='$b'");
$sqll=mysqli_query($con," update login  set status='2' where login_id='$b'");
header("location:admin_homemakers.php");
?>