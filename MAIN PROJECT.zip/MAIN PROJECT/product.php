 <?php
session_start();
$login=$_SESSION['login'];
$type=$_SESSION['type'];
//$usr_name=$_SESSION['usr_name'];
if($login)
{
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>FancyShop - Ecommerce Bootstrap Template</title>
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,500,600,700,800" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Handlee" rel="stylesheet">	
	<link rel="stylesheet" href="css/animate.css" />
	<link rel="stylesheet" href="css/owl.theme.default.min.css" />
	<link rel="stylesheet" href="css/owl.carousel.min.css" />
	<link rel="stylesheet" href="css/meanmenu.min.css" />
	<link rel="stylesheet" href="css/venobox.css" />
	<link rel="stylesheet" href="css/font-awesome.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />	
	<link rel="stylesheet" href="style.css" />
	<link rel="stylesheet" href="css/responsive.css" />	
</head>
	<body>
	
		<!--  Preloader  -->
		
		
		
	<?php include("a_menu.php"); 
	include("dbconnect.php");?>	
		
		
		
		
		
		
		
		
		
		<!-- Login Page -->
		<div class="login_page_area">
			<div class="container">
				<div class="row">
					
					</div>
					
						<div class="create_account_area">
							<h2 class="caa_heading">Add Category</h2>
							<?php
$se=" select * from `cat1_tbl` WHERE status=1";
$re=mysqli_query($con,$se);

 $no=1;
?>
					<table border="1" style="width: 50%;">
						<tr style="height: 40px">
						   
							<th style=" padding-left: 20px;">Sl No</th>
							<th style=" padding-left: 20px;">Category</th>
							<th style=" padding-left: 20px;">Remark</th>
							
							
							
						</tr>
						<?php
					
							while($row=mysqli_fetch_array($re))
  
 {
					?>
    <tr>
	<td style="font-size: 15px;"> 
   <?php 
        echo $no;
		$cat1_id=$row['cat_id'];
    ?>
<td style="font-size: 15px;"> <a href="product.php?cat1_id=<?php echo $cat1_id;?>" >
   <?php 
   
        echo $row['cat_name'];
    ?>
  </a></td>
<td><a href=delete_cat1.php?cat1_id=<?php echo $cat1_id;?>><img src=delete.png height=10 width=30 name="id"></a>&nbsp;&nbsp;&nbsp;<img src=edit.gif height=30 width=30>
<?php

$no++;
}
?>
<tr><td colspan=2>
<div class="login_password">
<tr><td colspan=3>
<form action=product_action1.php method=post>
<input type="text" name="cat_name" size=50  autocomplete="off" required="true"> 
&nbsp;&nbsp;<input type="submit" name="submit" value="+">
</form>
</div>
</table>
<?php
if(isset($_GET['cat1_id']))
{
	$cat1_id=$_GET['cat1_id'];
	//////////////
	$se1=" select * from `cat1_tbl` WHERE cat_id='$cat1_id'";
$re1=mysqli_query($con,$se1);
if($row1=mysqli_fetch_array($re1))
		$p=$row1['cat_name'];
	/////////////
?>

<style>

div.absolute {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 500px;
  height: 300px;
  border: 0px dashed #73AD21;
//background-color:lightgrey;
}
</style>
</head>
<body>


  <div class="absolute">Sub types of Category: <font color=red><b><?php echo $p;?>
  <?php
  $se1=" select * from `cat2_tbl` WHERE status=1 AND cat1_id='$cat1_id'";
$re1=mysqli_query($con,$se1);



?>
	<table border=1 width=100%>

	<tr style="height: 40px">
						   
							<th style=" padding-left: 20px;">Sl No</th>
							<th style=" padding-left: 20px;">Category</th>
							<th style=" padding-left: 20px;">Remark</th>
							
							
							
						</tr>
						<?php
					$slno=1;
							while($row1=mysqli_fetch_array($re1))
  
 {
					?>
    <tr>
	<td style="font-size: 15px;"> 
   <?php 
        echo $slno;
    ?>
<td style="font-size: 15px;"> <a href="admin_homemaker_details.php" >
   <?php 
        echo $row1['cat2_name'];
    ?>
  </a></td>
<td><img src=delete.png height=10 width=30>&nbsp;&nbsp;&nbsp;<img src=edit.gif height=30 width=30>

<?php
$slno++;
}
?>
<tr><td colspan=3>
<form action=product_action2.php method=post>
<input type="hidden" name=cat1_id value=<?php echo $cat1_id;?>>
<input type="text" name="cat2_name" size=45  autocomplete="off" required="true"> 
&nbsp;&nbsp;<input type="submit" name="submit" value="+">
</form>
</table>
  </div>

<?php } ?>


							
						</div>
					
				</div>
			</div>
		</div>		
		<br><br><br><br><br><br>
		<!--  FOOTER START  -->
		<footer class="footer_area">
			<div class="container">
				<div class="row">				
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Site Developed by Anittamol Chacko ,anittamolchacko@mca.ajce.in &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; MCA@AJCE
					
				</div>
			</div>
	
		
			

		<script src="js/vendor/jquery-1.12.4.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.meanmenu.min.js"></script>
		<script src="js/jquery.mixitup.js"></script>
		<script src="js/jquery.counterup.min.js"></script>
		<script src="js/waypoints.min.js"></script>
		<script src="js/wow.min.js"></script>
		<script src="js/venobox.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/simplePlayer.js"></script>
		<script src="js/main.js"></script>
	</body>
</html>

<?php
}
else
	header("location:../login.php");
?>