<?php
session_start();
$login=$_SESSION['login'];
$type=$_SESSION['type'];
$u_name=$_SESSION['user_id'];
if($login)
{
?>
<!DOCTYPE HTML>
<html lang="en-US">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>FancyShop - Ecommerce Bootstrap Template</title>
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,500,600,700,800" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Handlee" rel="stylesheet">	
	<link rel="stylesheet" href="css/animate.css" />
	<link rel="stylesheet" href="css/owl.theme.default.min.css" />
	<link rel="stylesheet" href="css/owl.carousel.min.css" />
	<link rel="stylesheet" href="css/meanmenu.min.css" />
	<link rel="stylesheet" href="css/venobox.css" />
	<link rel="stylesheet" href="css/font-awesome.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />	
	<link rel="stylesheet" href="style.css" />
	<link rel="stylesheet" href="css/responsive.css" />	
</head>
	<body>
	
		<!--  Preloader  -->
		
		<!--<div class="preloader">
			<div class="status-mes">
				<div class="bigSqr">
					<div class="square first"></div>
					<div class="square second"></div>
					<div class="square third"></div>
					<div class="square fourth"></div>
				</div>
				<div class="text_loading text-center">loading</div>
			</div>
		</div>
		
		<!--  Start Header  -->
		
		<!--  End Header  -->
		
		<!-- Page item Area -->
		
		
		
		<!-- Login Page -->
		<?php include("h_menu.php"); 
	include("dbconnect.php");?>
		<div class="login_page_area">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-6 col-xs-12">
						
					</div>
					<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="create_account_area">
							<h2 class="caa_heading">Change photo..?</h2>
							<div class="caa_form_area">
								<div class="caa_form_group">
									<div class="login_email">
									
										<div class="login_password">
										<div class="login_password">
										<label>Email_id : <font color=red><?php echo $u_name; ?></font></label>
										
									</div>
									
									
										
										
		<form action="changephoto_action.php" method="post" enctype="multipart/form-data">
        Select image to upload:
         <input type="file" name="fileToUpload" id="fileToUpload" onchange="return checkfiles()">
<script>				  
function checkfiles() {
    var formData = new FormData();
 
    var file = document.getElementById("fileToUpload").files[0];
 
    formData.append("Filedata", file);
    var t = file.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "bmp" && t != "gif") {
        alert('Please select a valid image file');
        document.getElementById("fileToUpload").value = '';
        return false;
    }
    if (file.size > 1024000) {
        alert('Max Upload size is 1MB only');
        document.getElementById("fileToUpload").value = '';
        return false;
    }
    return true;
}
</script>
        <input type="submit" name="submit" value="UPLOAD"/>
    									  <?php
										if(isset($_GET['error']))
											{
											$error=$_GET['error'];
											echo "<font color=red>$error";
											}
											?>                 
									</form>
									<?php
	for($i=1;$i<=4;$i++)
	{
		echo "<br>";
	}
?>	
								</div>
							
						</div>
					</div>
				</div>
			</div>
		</div>	

	
		
		<!--  FOOTER START  -->
		<!--<footer class="footer_area">
		 	<div class="container">
				<div class="row">				
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Site Developed by Anittamol Chacko ,anittamolchacko@mca.ajce.in &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; MCA@AJCE
					
				</div>
			</div>-->
	
		
			

		<script src="js/vendor/jquery-1.12.4.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.meanmenu.min.js"></script>
		<script src="js/jquery.mixitup.js"></script>
		<script src="js/jquery.counterup.min.js"></script>
		<script src="js/waypoints.min.js"></script>
		<script src="js/wow.min.js"></script>
		<script src="js/venobox.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/simplePlayer.js"></script>
		<script src="js/main.js"></script>
	</body>
</html>
<?php
}
else
header("location:login.php");
?>	
	