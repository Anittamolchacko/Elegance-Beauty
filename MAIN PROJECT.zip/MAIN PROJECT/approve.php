<?php
include "dbconnect.php";

$b=$_POST['id'];
//echo "popo";

$sqll=mysqli_query($con,"update login set status=1 where login_id='$b'");
      
	  header("location:admin_homemakers.php");

?>