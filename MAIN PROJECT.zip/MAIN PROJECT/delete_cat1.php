<?php
include "dbconnect.php";

 $b=$_GET['cat1_id'];
 echo "popo";
 echo $b;
 $sql=mysqli_query ($con,"delete from cat1_tbl where cat_id='$b'");
 $sq2=mysqli_query ($con,"delete from cat2_tbl where cat1_id='$b'");
 header("location:product.php");
 ?>