<?php
session_start();

include "dbconnect.php";
$cname=$_POST['cname'];
$caddress=$_POST['caddress'];
$cplace=$_POST['cplace'];
$cdistrict=$_POST['cdistrict'];
$cphone=$_POST['cphone'];
$login_id=$_SESSION['login_id'];
echo $cdistrict;
$sqll=mysqli_query($con," update customers_reg  set name='$cname',address='$caddress',place='$cplace',district='$cdistrict',phone='$cphone' where login_id='$login_id'");
if($sqll)
{
header("location:custprofile.php?error=Profile changed Sucessfuly!...");
}
else
{
	echo "error:".$sqll."<br>".mysqli_error($con);
}
?>