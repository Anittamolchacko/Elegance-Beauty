		 <!--  HEADER START  -->
			
			<div class="header_btm_area">
				<div class="container">
					<div class="row">		
						<div class="col-xs-12 col-sm-12 col-md-3"> 
							<a class="logo" href="index.php"> <img alt="" src="img/logo/logo.png"></a> 
						</div><!--  End Col -->
						
						<div class="col-xs-12 col-sm-12 col-md-9 text-right">
							<div class="menu_wrap">
								<div class="main-menu">
									<nav>
										<ul>
											<li><a href="index.php">home</a>					
											</li>									
											
											<li><a href="">Shop <i class="fa fa-angle-down"></i></a>
												<!-- Sub Menu -->
												<ul class="sub-menu">
													<li><a href="product-details.php">Product Details</a></li>
													
												</ul>
											</li>
											<li><a href="shop.php">About <i class="fa fa-angle-down"></i></a>
												
													</li>
											<li><a href="">Signup <i class="fa fa-angle-down"></i></a>
											<!-- Sub Menu -->
												<ul class="sub-menu">
													<li><a href="hsignup.php">Homemaker</a></li>
													<li><a href="csignup.php">Customer</a></li>
												
												</ul>
											</li>
									
											</li>
											
											<li><a href="login.php">Login</a></li>
										</ul>
									</nav>
								</div> <!--  End Main Menu -->					

								
								
								<div class="right_menu">
									<ul class="nav justify-content-end">
										<li>
											<div class="search_icon">
												<i class="fa fa-search search_btn" aria-hidden="true"></i>
												<div class="search-box">
													<form action="#" method="get">
														<div class="input-group">
															<input type="text" class="form-control"  placeholder="enter keyword"/>				
															<button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>			
														</div>
													</form>
												</div>
											</div>
										</li>
										
										<li>
											
												
												
												
																								
											</div>	
											
										</li>
									</ul>
								</div>							
							</div>
						</div><!--  End Col -->										
					</div>
				</div>
			</div>
		</header>