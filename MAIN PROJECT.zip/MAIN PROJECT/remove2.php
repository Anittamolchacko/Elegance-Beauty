<html lang="en">
<body>
    <form action="remove1.php" method="post" enctype="multipart/form-data">
        Select image to upload:
         <input type="file" name="fileToUpload" id="fileToUpload">
        <input type="submit" name="submit" value="UPLOAD"/>
    </form>
</body>
</html>