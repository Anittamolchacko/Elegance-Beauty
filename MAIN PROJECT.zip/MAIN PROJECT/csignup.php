<?php
include 'dbconnect.php';
$q1="select * from district_tbl";
$db1=mysqli_query($con,$q1);
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<script type="text/javascript">
function validateform()
{
var x=document.forms["myform"]["name"].value;
if(x=="")
{
alert("Please fill name");
return false;
}
if ((x.length < 3) || (x.length > 30))
  {
    alert("Your Character must be 3 to 15 Character");
    //document.getElementById('name').focus();
     return false;
   }
   var pattern1 = new RegExp("^[a-zA-Z ]*$"); 
      if(!pattern1.test(document.myform.name.value)) 
	  {
      alert("Error: Please enter valid name!");
      myform.name.focus();
    return false;
     }
var w=document.forms["myform"]["address"].value;
if(w=="")
{
alert("Please fill address");
return false;
}
var y=document.forms["myform"]["place"].value;
if(y=="")
{
alert("Please fill place");
return false;
}
var y=document.forms["myform"]["district"].value;
if(y=="")
{
alert("Please select district");
return false;
}
var email = document.myform.email.value;
  atpos = email.indexOf("@");
  dotpos = email.lastIndexOf(".");
  if (email == "" || atpos < 1 || ( dotpos - atpos < 2 )) 
  {
     alert("Please enter correct email ID")
   document.getElementById('cust_email').focus();
     return false;
  }
  var o=document.forms["myform"]["password1"].value;
if(o=="")
{
alert("Please Fill password Field");
document.getElementById('password1').focus();
return false;
}
if(o.length<8){  
   alert("Password must be at least 8 characters long.");  
   document.getElementById('password1').focus();
    return false;  
}

var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})"); 
  if(!strongRegex.test(document.myform.password1.value)) 
	  {
      alert("Error: password should contain atleast one uppercase,lowercase ,digit and special characters!");
      myform.password1.focus();
    return false;
     } 
   
var h=document.forms["myform"]["cpassword"].value;
if(h=="")
{
alert("Please Fill confirm password Field");
document.getElementById('cpassword').focus();
return false;
}
var pwd = document.getElementById("password1").value;
       var cpassword1 = document.getElementById("cpassword").value;
        if (pwd != cpassword1) {
            alert("Passwords do not match.");
			document.getElementById('cpassword').focus();
            return false;
        }
		if( document.myform.phone.value == "" ||
           isNaN( document.myform.phone.value) ||
           document.myform.phone.value.length != 10 )
   {
     alert( "Please provide a valid Mobile Number upto 10 digit" );
   document.getElementById('phone').focus();
     return false;
   }
   var pattern = new RegExp("^([6-9]{1})([0-9]{9})$"); 
      if(!pattern.test(document.myform.phone.value)) 
	  {
      alert("Error: Phone Number is invalid!");
      myform.phone.focus();
    return false;
     }


return true;
}
	</script>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>FancyShop - Ecommerce Bootstrap Template</title>
	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,500,600,700,800" rel="stylesheet"> 
	<link href="https://fonts.googleapis.com/css?family=Handlee" rel="stylesheet">	
	<link rel="stylesheet" href="css/animate.css" />
	<link rel="stylesheet" href="css/owl.theme.default.min.css" />
	<link rel="stylesheet" href="css/owl.carousel.min.css" />
	<link rel="stylesheet" href="css/meanmenu.min.css" />
	<link rel="stylesheet" href="css/venobox.css" />
	<link rel="stylesheet" href="css/font-awesome.css" />
	<link rel="stylesheet" href="css/bootstrap.min.css" />	
	<link rel="stylesheet" href="style.css" />
	<link rel="stylesheet" href="css/responsive.css" />	
</head>
	<body>
	
		<!--  Preloader  -->
		
		<div class="preloader">
			<div class="status-mes">
				<div class="bigSqr">
					<div class="square first"></div>
					<div class="square second"></div>
					<div class="square third"></div>
					<div class="square fourth"></div>
				</div>
				<div class="text_loading text-center">loading</div>
			</div>
		</div>
		
		<!--  Start Header  -->
		<?php include ('menu.php'); ?>
		<!--  End Header  -->
		
		<!-- Page item Area -->
		
		
		
		<!-- Login Page -->
		<div class="login_page_area">
			<div class="container">
			
				<div class="row">
					
					</div>
					<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="create_account_area">
							<h2 class="caa_heading">New Registration, for <font color=red>Customer</font></h2>
							<div class="caa_form_area">
								<div class="caa_form_group">
									<div class="login_email">
									<form action=csignup_action.php method="POST" name="myform" onsubmit="return validateform()">
										<label>Name</label>
										<div class="input-area"><input type="text" name="name" ></div>
									</div>
								<div class="login_password">
										<label>Address</label>
										<div class="input-area"><textarea cols="6" rows="2"  id="address"name="address"></textarea></div>
									</div>
									<div class="login_password">
										<label>Place</label>
										<div class="input-area"><input type="text"  id="place"name="place"/></div>
									</div>
									
									
									<div class="login_password">
						             <label>District</label>
										<div class="input-area">
									<select name="district" id="district">
									
									<option></option>
									<?php
						while($fetch=mysqli_fetch_array($db1))
						{
                            ?>
               <option value="<?php echo $fetch['district_id']?>"><?php echo $fetch['district_name']?>  <?php
                        }
						?>
									</select></div>
									</div>
									
									
									<div class="login_password">
										<label>Email_id</label>
										<div class="input-area"><input type="email"  id="email"name="email" /></div>
									</div>
									<div class="login_password">
										<label>Password</label>
										<div class="input-area"><input type="password" id="password1" name="password1"/></div>
									</div>
									<div class="login_password">
										<label>Confirm Password</label>
										<div class="input-area"><input type="password" name="cpassword" id="cpassword"/></div>
									</div>
									
									
									
									<div class="login_password">
										<label>Phone</label>
										<div class="input-area"><input type="text" id="phone" name="phone" /></div>
									</div>
									
									<p class="forgot_password">
										<a href="#" title="Recover your forgotten password" rel="">Forgot your password?</a>
									</p>
									<!--<button  name="register"  class="btn btn-default acc_btn"> 
										<span> <i class="fa fa-lock btn_icon"></i> Register</span> 
									</button>-->
									<input type="submit" name="submit" value="Register">
									
									<!--<button type="submit" id="acc_Login" name="cancel" class="btn btn-default acc_btn"> 
										<span> <i class="fa fa-lock btn_icon"></i> Cancel</span> -->
										<input type="submit" name="submit" value="Cancel">
									</button>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>		
		
		<!-- INSERT VALUES -->
		
		<!--  FOOTER START  -->
		<footer class="footer_area">
			<div class="container">
				<div class="row">				
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Site Developed by Anittamol Chacko ,anittamolchacko@mca.ajce.in &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; MCA@AJCE
					
				</div>
			</div>
	
		
			

		<script src="js/vendor/jquery-1.12.4.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.meanmenu.min.js"></script>
		<script src="js/jquery.mixitup.js"></script>
		<script src="js/jquery.counterup.min.js"></script>
		<script src="js/waypoints.min.js"></script>
		<script src="js/wow.min.js"></script>
		<script src="js/venobox.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/simplePlayer.js"></script>
		<script src="js/main.js"></script>
	</body>
</html>