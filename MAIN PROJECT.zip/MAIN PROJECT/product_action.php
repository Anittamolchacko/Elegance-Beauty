<?php
include "dbconnect.php";
$cat_name=$_POST['cat_name'];
echo "popo";
echo $cat_name;

$q4="insert into cat1_tbl(`cat_name`,`status`) values('$cat_name','1')";
$q5=mysqli_query($con,$q4);
echo $q4;
	  header("location:product.php");

?>