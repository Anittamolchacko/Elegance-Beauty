<?php
session_start();
include('dbconnect.php');
$u_name=$_SESSION['user_id'];
if(isset($_POST['submit']))
{
//$uname=	$_POST["uname"];
$old=$_POST["oldpswd"];
$new=$_POST["pswd1"];
$conf=$_POST["cpassword"];
echo $old;
echo $new;
echo $conf;
//$log=$_SESSION['login'];
$re=mysqli_query($con,"select * from login where username='$u_name' and pass='$old'");

if(mysqli_num_rows($re)>0)
{
	
	mysqli_query($con,"update login set pass='$new' where username='$u_name'");
	header("location: custchangepwd.php?error=Successfully Password Changed.....");
	
										
	}
	else
	{
		header("location: custchangepwd.php?error=Wrong Password .....");
	}
}
?>