<?php
include "dbconnect.php";
$cat1_id=$_POST['cat1_id'];
$cat2_name=$_POST['cat2_name'];
echo "popo";
echo $cat2_name;
echo $cat1_id;

$q4="insert into cat2_tbl('cat1_id', 'cat2_name`,`status`) values('$cat1_id','$cat2_name','1')";
$q5=mysqli_query($con,$q4);
echo $q4;
	//  header("location:product.php");

?>